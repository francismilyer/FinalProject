module.exports = {
    SECRET: 'jennie-ruby-janee'
};